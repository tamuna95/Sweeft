//: [Previous](@previous)

import Foundation
//გვაქვს N ფიცრისგან შემდგარი ხიდი. სიძველის გამო ზოგიერთი ფიცარი ჩატეხილია. ზურიკოს შეუძლია გადავიდეს შემდეგ ფიცარზე ან გადაახტეს ერთ ფიცარს. (რათქმაუნდა ჩატეხილ   ფიცარზე ვერ გადავა)
//   ჩვენი ამოცანაა დავითვალოთ რამდენი განსხვავებული კომბინაციით შეუძლია ზურიკოს ხიდის გადალახვა. გადმოგვეცემა ხიდის სიგრძე და ინფორმაცია ჩატეხილ ფიცრებზე. 0 აღნიშნავს ჩატეხილ ფიცარს 1_ანი კი მთელს. დასაწყისისთვის ზურიკო დგას ხიდის ერთ მხარეს (არა პირველ ფიცარზე) და გადალახვად ჩათვლება ხიდის მეორე მხარე (ბოლო ფიცრის შემდეგი ნაბიჯი)
//
//
//   func countWays(n: Int, steps: [Int]) -> Int {
//           // Your code goes here
//   }
//
//   Examples:
//   countWays(n: 3, steps: [0, 1, 0]) ➞ 1
//   countWays(n: 4, steps: [0, 1, 1, 0]) ➞ 1
//   countWays(n: 5, steps: [1, 1, 0, 1, 1]) ➞ 4 // (s, 1, 2, 4, 5, f), (s, 1, 2, 4, f), (s, 2, 4, 5, f), (s, 2, 4, f)  s - ხიდის ერთი მხარე, f - ხიდის მეორე მხარე


func countWays(n: Int, steps: [Int]) -> Int {

    var numberOfWays = Array(repeating: 0, count: n + 1)
    numberOfWays[0] = 1
    for i in 1...n {
        if steps[i - 1] == 0 {
            numberOfWays[i] = 0
        } else if i - 2 < 0 {
            numberOfWays[i] = numberOfWays[i - 1]
            }
        else {
            numberOfWays[i] = numberOfWays[i - 1] + numberOfWays[i - 2]

    }
       }
  return numberOfWays[n] * steps[n - 1] + numberOfWays[n - 1] * steps[n - 2]
}
print(countWays(n: 3, steps: [0, 1, 0]))      // ➞ 1
print(countWays(n: 4, steps: [0, 1, 1, 0]))
print(countWays(n: 5, steps: [1, 1, 0, 1, 1]))
