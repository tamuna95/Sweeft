//მოცემულია String რომელიც შედგება „(" და „)" ელემენტებისგან. დაწერეთ ფუნქცია რომელიც აბრუნებს ფრჩხილები არის თუ არა მათემატიკურად სწორად დასმული.
//
//    func isProperly(sequence: String) -> Bool {
//        // Your code goes here
//    }
//
//    Examples:
//    isProperly(sequence: "(()())") ➞ true
//    isProperly(sequence: ")(()") ➞ false
//    isProperly(sequence: "(()())(") ➞ false

func isProperly(sequence: String) -> Bool {
    var characterArr = [Character]()
    
    for char in sequence {
        if char == "(" {
            characterArr.append(char)
        } else if char == ")" {
            if characterArr.isEmpty {
                return false
            } else {
                characterArr.removeLast()
            }
        }
    }
    
    return characterArr.isEmpty
}


print(isProperly(sequence: "(()())"))
print(isProperly(sequence: ")(()"))
print(isProperly(sequence: "(()())("))

